package trelloTests;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateTableStepdefs {
    private WebDriver driver;
    JavascriptExecutor js;


    @Before
    public void setUp() {
        driver = new ChromeDriver();
        js = (JavascriptExecutor) driver;
    }
    @After
    public void tearDown() {
        driver.quit();
    }

    @Given("^jestem na podgladzie tablic$")
    public void jestemNaPodgladzieTablic() throws InterruptedException {
        driver.get("https://trello.com/cyprianczerwinski/boards");
        Thread.sleep(3000);
    }

    @When("^Klikam na utworz nowa tablice$")
    public void klikam_na_utworz_nowa_tablice() throws InterruptedException {
        driver.findElement(By.cssSelector(".boards-page-board-section:nth-child(4) p > span")).click();
        Thread.sleep(3000);

    }

    @And("^Podaje nazwe nowa tablica$")
    public void podaje_nazwe_nowa_tablica() throws InterruptedException {
        driver.findElement(By.cssSelector(".nch-textfield__input")).sendKeys("testowa tablica");
        Thread.sleep(3000);

    }

    @Then("^Zostaje przekierowany do nowo utworzonej tablicy$")
    public void zostaje_przekierowany_do_nowo_utworzonej_tablicy() {
        driver.findElement(By.cssSelector(".nch-textfield__input")).sendKeys(Keys.ENTER);

    }

}
